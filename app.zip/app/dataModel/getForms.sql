/**
 *
 * @author jskonst
 * @name getForms
 * @public 
 */ 
Select * 
From templates t1
 Where t1.type_id = 148181449159200