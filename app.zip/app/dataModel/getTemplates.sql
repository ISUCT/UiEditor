/**
 *
 * @author jskonst
 * @name getTemplates
 * @public 
 */ 
Select * 
From templates t1
 Where t1.type_id = 148181448228600