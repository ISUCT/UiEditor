/**
 *
 * @author jskonst
 * @name groups
 * @public 
 */ 
Select * 
From MTD_GROUPS t1