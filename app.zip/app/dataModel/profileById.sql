/**
 *
 * @author jskonst
 * @name profileById
 * @public 
 */ 
Select * 
From userprofile t1
 Where :profileId = t1.userprofile_id