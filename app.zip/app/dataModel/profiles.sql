/**
 *
 * @author jskonst
 * @name profiles
 * @public 
 */ 
Select * 
From userprofile t1