/**
 *
 * @author jskonst
 * @name templateTypes
 * @public 
 */ 
Select * 
From templatetype t1