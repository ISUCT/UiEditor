/**
 *
 * @author jskonst
 * @name templates
 * @public 
 */ 
Select * 
From templates t1