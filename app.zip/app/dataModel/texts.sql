/**
 *
 * @author jskonst
 * @name texts
 * @public 
 */ 
Select * 
From text_edit t1