/**
 *
 * @author jskonst
 * @name users
 * @public 
 */ 
Select * 
From MTD_USERS t1